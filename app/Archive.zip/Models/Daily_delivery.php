<?php

namespace App\Models;

use CodeIgniter\Model;

class Daily_delivery extends Model {
  protected $table = "daily_delivery";
  protected $allowedFields = ['email', 'campaign_id', 'impression', 'click', 'ctr', 'win_rate', 'view', 'completed_view', 'time'];

  public function getUserData($campaign, $email) {
    $sql = 'SELECT * FROM `daily_delivery` WHERE `campaign_id`=? and `email`=? ORDER BY `time` ASC';
    $result = $this->db->query($sql, [$campaign, $email]);
    return $result->getResultArray();
  }
}